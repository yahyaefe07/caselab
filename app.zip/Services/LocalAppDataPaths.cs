using System;
using System.IO;
using System.IO.Compression;
using System.Text.Json;
using cs2fakecaseopener.Models;

namespace cs2fakecaseopener.Services;

public static class LocalAppDataPaths
{
    private static readonly JsonSerializerOptions ProfileJsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    public static string Root => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "CS2FakeCase");

    public static string Cache => Path.Combine(Root, "Cached");
    public static string SettingsFile => Path.Combine(Root, "settings.json");
    public static string ProfileFile => Path.Combine(Root, "profile.json");
    public static string InventoryFile => Path.Combine(Root, "inventory.json");
    public static string BackupDirectory => Path.Combine(Root, "Backups");

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(Root);
        Directory.CreateDirectory(Cache);
        Directory.CreateDirectory(BackupDirectory);

        CreateFileIfMissing(SettingsFile, "{\n  \"themeMode\": \"auto\",\n  \"soundEnabled\": true\n}");
        CreateFileIfMissing(InventoryFile, "{\n  \"items\": []\n}");
    }

    /// <summary>Returns the saved name, or an empty value when setup has not been completed.</summary>
    public static string GetPlayerName()
    {
        var profile = LoadProfile();
        if (profile is not null)
        {
            var playerName = profile.DisplayName.Trim();
            return string.Equals(playerName, "Define", StringComparison.OrdinalIgnoreCase)
                || string.Equals(playerName, "PLAYER_01", StringComparison.OrdinalIgnoreCase)
                ? string.Empty
                : playerName;
        }

        return string.Empty;
    }

    /// <summary>Reads the current saved profile directly from profile.json.</summary>
    public static PlayerProfile? LoadProfile()
    {
        if (!File.Exists(ProfileFile)) return null;

        try
        {
            return JsonSerializer.Deserialize<PlayerProfile>(File.ReadAllText(ProfileFile), ProfileJsonOptions);
        }
        catch (JsonException)
        {
            return null;
        }
    }

    /// <summary>Reads inventory.json. Invalid or missing data safely appears as an empty inventory.</summary>
    public static InventorySave LoadInventory()
    {
        if (!File.Exists(InventoryFile)) return new InventorySave();

        try
        {
            return JsonSerializer.Deserialize<InventorySave>(File.ReadAllText(InventoryFile), ProfileJsonOptions)
                ?? new InventorySave();
        }
        catch (JsonException)
        {
            return new InventorySave();
        }
    }

    /// <summary>Creates a timestamped ZIP copy of all local CaseLab data.</summary>
    public static string CreateBackup()
    {
        Directory.CreateDirectory(BackupDirectory);
        var fileName = $"CaseLab-backup-{DateTime.Now:yyyy-MM-dd-HH-mm-ss}.zip";
        var backupPath = Path.Combine(BackupDirectory, fileName);

        using var archive = ZipFile.Open(backupPath, ZipArchiveMode.Create);
        foreach (var file in Directory.EnumerateFiles(Root, "*.json", SearchOption.TopDirectoryOnly))
        {
            archive.CreateEntryFromFile(file, Path.GetFileName(file));
        }

        return backupPath;
    }

    /// <summary>Resets editable JSON data while keeping cached images and existing backups intact.</summary>
    public static void ResetSaveData()
    {
        CreateBackup();
        File.Delete(ProfileFile);
        File.WriteAllText(InventoryFile, "{\n  \"items\": []\n}");
        File.WriteAllText(SettingsFile, "{\n  \"themeMode\": \"auto\",\n  \"soundEnabled\": true\n}");
    }

    public static string GetThemeMode()
    {
        try
        {
            using var settings = JsonDocument.Parse(File.ReadAllText(SettingsFile));
            return settings.RootElement.TryGetProperty("themeMode", out var themeMode)
                ? themeMode.GetString()?.ToLowerInvariant() ?? "auto"
                : "auto";
        }
        catch (JsonException)
        {
            return "auto";
        }
    }

    public static void SaveThemeMode(string themeMode)
    {
        var settings = new { themeMode, soundEnabled = true };
        File.WriteAllText(SettingsFile, JsonSerializer.Serialize(settings, ProfileJsonOptions));
    }

    /// <summary>Creates or updates the local player profile with the chosen name.</summary>
    public static void SavePlayerName(string playerName)
    {
        var profile = new PlayerProfile
        {
            DisplayName = playerName,
            Level = 1,
            Experience = 0,
            Balance = 0
        };

        File.WriteAllText(ProfileFile, JsonSerializer.Serialize(profile, ProfileJsonOptions));
    }

    private static void CreateFileIfMissing(string path, string contents)
    {
        if (!File.Exists(path))
        {
            File.WriteAllText(path, contents);
        }
    }
}
