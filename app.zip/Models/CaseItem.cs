namespace cs2fakecaseopener.Models;

/// <summary>One fictional, locally owned cosmetic item.</summary>
public sealed class CaseItem
{
    public string Id { get; init; } = string.Empty;
    public string Name { get; init; } = string.Empty;
    public string Rarity { get; init; } = string.Empty;
    public decimal EstimatedValue { get; init; }
}
