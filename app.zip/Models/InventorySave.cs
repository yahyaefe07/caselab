using System.Collections.Generic;

namespace cs2fakecaseopener.Models;

/// <summary>The contents of inventory.json.</summary>
public sealed class InventorySave
{
    public List<CaseItem> Items { get; set; } = new();
}
