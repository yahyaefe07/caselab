namespace cs2fakecaseopener.Models;

/// <summary>The player data stored in profile.json.</summary>
public sealed class PlayerProfile
{
    public string DisplayName { get; set; } = string.Empty;
    public int Level { get; set; } = 1;
    public int Experience { get; set; }
    public decimal Balance { get; set; }
}
