namespace cs2fakecaseopener.ViewModels;

/// <summary>Starting point for dashboard state; persisted data will be introduced with inventory.</summary>
public sealed class DashboardViewModel
{
    public decimal SimulatedBalance { get; set; } = 2450.50m;
    public int Level { get; set; } = 12;
    public int Experience { get; set; } = 680;
}
