using System;
using System.Linq;
using System.Text.RegularExpressions;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Media;
using Windows.UI;
using cs2fakecaseopener.Models;
using cs2fakecaseopener.Services;

namespace cs2fakecaseopener;

public sealed partial class MainWindow : Window
{
    private static readonly Regex PlayerNamePattern = new(
        @"^[\p{L}\p{M}]+(?:[ '\-][\p{L}\p{M}]+)*$",
        RegexOptions.CultureInvariant);

    private bool _updatingThemeToggle;
    private int _sessionCasesOpened = 0;
    private decimal _sessionSpent = 0m;
    private string _sessionBestDrop = "No drops yet";

    public MainWindow()
    {
        InitializeComponent();
        LocalAppDataPaths.EnsureCreated();
        ReloadLocalData();
        UpdateSessionStats();
    }

    private void ReloadLocalData()
    {
        ApplyThemeFromSettings();

        var profile = LocalAppDataPaths.LoadProfile();
        if (profile is null || string.IsNullOrWhiteSpace(LocalAppDataPaths.GetPlayerName()))
        {
            NameSetupOverlay.Visibility = Visibility.Visible;
        }
        else
        {
            ApplyProfile(profile);
            NameSetupOverlay.Visibility = Visibility.Collapsed;
        }

        var inventory = LocalAppDataPaths.LoadInventory();
        var itemCount = inventory.Items?.Count ?? 0;
        var inventoryValue = inventory.Items?.Sum(item => item.EstimatedValue) ?? 0m;
        InventoryValueText.Text = $"$ {inventoryValue:N2}";
        InventoryCountText.Text = $"{itemCount:N0} collected item{(itemCount == 1 ? string.Empty : "s")}";
    }

    private void ApplyProfile(PlayerProfile profile)
    {
        var level = Math.Clamp(profile.Level, 1, 999);
        var experience = Math.Clamp(profile.Experience, 0, 1000);

        PlayerNameText.Text = profile.DisplayName;
        PlayerLevelText.Text = $"Level {level}  •  {GetRank(level)}";
        BalanceText.Text = $"$ {profile.Balance:N2}";
        ExperienceText.Text = $"{experience:N0} / 1,000 XP";
        ExperienceProgress.Value = experience;
    }

    private static string GetRank(int level) => level switch
    {
        999 => "CASELAB IMMORTAL",
        >= 850 => "Apex",
        >= 700 => "Mythic",
        >= 500 => "Grandmaster",
        >= 350 => "Master",
        >= 200 => "Elite",
        >= 100 => "Vanguard",
        >= 50 => "Specialist",
        >= 25 => "Operative",
        >= 10 => "Scout",
        _ => "Rookie"
    };

    private void ApplyThemeFromSettings()
    {
        var mode = LocalAppDataPaths.GetThemeMode();
        var hour = DateTime.Now.Hour;
        var useDark = mode switch
        {
            "dark" => true,
            "light" => false,
            _ => hour >= 19 || hour < 7
        };

        ApplyTheme(useDark, false);
    }

    private void ApplyTheme(bool useDark, bool savePreference)
    {
        AppRoot.RequestedTheme = useDark ? ElementTheme.Dark : ElementTheme.Light;
        AppRoot.Background = new SolidColorBrush(useDark ? Color.FromArgb(255, 17, 19, 26) : Color.FromArgb(255, 245, 246, 248));
        SidebarPanel.Background = new SolidColorBrush(useDark ? Color.FromArgb(255, 23, 26, 35) : Color.FromArgb(255, 255, 255, 255));
        ((SolidColorBrush)AppRoot.Resources["PanelBrush"]).Color = useDark ? Color.FromArgb(255, 26, 29, 39) : Color.FromArgb(255, 255, 255, 255);
        ((SolidColorBrush)AppRoot.Resources["MutedTextBrush"]).Color = useDark ? Color.FromArgb(255, 148, 155, 170) : Color.FromArgb(255, 85, 92, 104);

        _updatingThemeToggle = true;
        ThemeToggle.IsOn = useDark;
        _updatingThemeToggle = false;

        if (savePreference)
        {
            LocalAppDataPaths.SaveThemeMode(useDark ? "dark" : "light");
        }
    }

    private void ThemeToggle_Toggled(object sender, RoutedEventArgs e)
    {
        if (!_updatingThemeToggle)
        {
            ApplyTheme(ThemeToggle.IsOn, true);
        }
    }

    private void RefreshButton_Click(object sender, RoutedEventArgs e)
    {
        LocalAppDataPaths.EnsureCreated();
        ReloadLocalData();
    }

    private void SavePlayerNameButton_Click(object sender, RoutedEventArgs e)
    {
        var playerName = PlayerNameInput.Text.Trim();
        if (playerName.Length < 2 || playerName.Length > 30)
        {
            NameErrorText.Text = "Your name must be between 2 and 30 characters.";
            NameErrorText.Visibility = Visibility.Visible;
            return;
        }

        if (!PlayerNamePattern.IsMatch(playerName))
        {
            NameErrorText.Text = "Use letters only. Spaces, hyphens, and apostrophes are allowed between words.";
            NameErrorText.Visibility = Visibility.Visible;
            return;
        }

        LocalAppDataPaths.SavePlayerName(playerName);
        NameErrorText.Visibility = Visibility.Collapsed;
        ReloadLocalData();
    }

    private void SettingsButton_Click(object sender, RoutedEventArgs e) => SettingsOverlay.Visibility = Visibility.Visible;
    private void CloseSettingsButton_Click(object sender, RoutedEventArgs e) => SettingsOverlay.Visibility = Visibility.Collapsed;

    private void ExportBackupButton_Click(object sender, RoutedEventArgs e)
    {
        var backupPath = LocalAppDataPaths.CreateBackup();
        ShowMessage("Backup created", $"Local JSON data exported to:\n{backupPath}");
    }

    private void ResetButton_Click(object sender, RoutedEventArgs e)
    {
        LocalAppDataPaths.ResetSaveData();
        SettingsOverlay.Visibility = Visibility.Collapsed;
        ReloadLocalData();
        ShowMessage("Reset complete", "A ZIP backup was created first. Your profile, inventory, and settings are reset.");
    }

    private void UpdateSessionStats()
    {
        SessionCasesText.Text = $"{_sessionCasesOpened:N0} case{(_sessionCasesOpened == 1 ? string.Empty : "s")} opened";
        SessionSpentText.Text = $"$ {_sessionSpent:N2}";
        SessionBestDropText.Text = _sessionBestDrop;
    }

    private void InventoryButton_Click(object sender, RoutedEventArgs e) => ShowMessage("Inventory", "Your inventory screen is the next feature to build.");
    private void CasesButton_Click(object sender, RoutedEventArgs e) => ShowMessage("Cases", "Case browsing and opening will be added in the next step.");

    private void ShowMessage(string title, string message)
    {
        var dialog = new ContentDialog
        {
            Title = title,
            Content = message,
            CloseButtonText = "Got it",
            XamlRoot = Content.XamlRoot
        };
        _ = dialog.ShowAsync();
    }
}
